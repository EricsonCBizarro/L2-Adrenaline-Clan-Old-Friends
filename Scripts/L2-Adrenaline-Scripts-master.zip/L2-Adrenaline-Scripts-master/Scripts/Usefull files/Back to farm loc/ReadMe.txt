1) Change NickName_Settings.ini NickName to the name of the character on which the script will run
2) Information on configuring the config inside NickName_Settings.ini